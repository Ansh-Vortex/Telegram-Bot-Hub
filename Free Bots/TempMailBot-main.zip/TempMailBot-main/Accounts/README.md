# Accounts
List of accounts that uses bot. this is nedded to save Emails data for user.
