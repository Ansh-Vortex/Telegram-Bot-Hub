class ArchiveExceptionHandler(Exception):
    pass

class DDLExceptionHandler(Exception):
    pass
