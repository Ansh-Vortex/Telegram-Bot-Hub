TOKEN = "YOUR_TOKEN_HERE"
QUESTIONS_JSON_PATH = "data/questions.json"
STAFF_JSON_PATH = "data/staff.json"
REPORT_JSON_PATH = "data/reports.json"