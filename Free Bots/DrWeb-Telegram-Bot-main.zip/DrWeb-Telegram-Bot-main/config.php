<?php
error_reporting(0);
$token		= "";												// set your bot access token
$admins		= ['0', '1'];										// set bot admins user id
$channel	= "iNeoTeam";										// without @
$api		= "https://api.ineo-team.ir";						// don't change it
$cs			= ['creator', 'administrator', 'member'];			// don't change it
$char		= array('\'', '"', '$', ';', ',', '`', '~', '*');	// don't change it
