# Thunder/server/exceptions.py

class InvalidHash(Exception):
    pass

class FileNotFound(Exception):
    pass
