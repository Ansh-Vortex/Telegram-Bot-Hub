

from aiogram.utils.callback_data import CallbackData

whisper_callback = CallbackData("whisper", "msg_id")