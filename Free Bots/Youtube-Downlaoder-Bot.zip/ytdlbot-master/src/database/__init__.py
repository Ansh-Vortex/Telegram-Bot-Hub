#!/usr/bin/env python3
# coding: utf-8

# ytdlbot - __init__.py.py

from database.cache import Redis
